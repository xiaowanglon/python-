"""
读取日志文件并修改，统计测试用例并生成失败用例文档
"""
PASS_num = 0
FAIL_num = 0
TEXT_num = 0
my_list1 = []
my_list2 = []
result_list = []
id_num_list = []
check_list = []


def counter(res):
    global PASS_num, FAIL_num, TEXT_num
    TEXT_num += 1
    if 'PASS' in res:
        PASS_num += 1
    elif 'FAIL' in res:
        FAIL_num += 1

with open("log_check.txt", "w+") as nf:
    with open("log.txt", "r") as f:
        for x in f.readlines():
            if x == "\n":
                continue
            my_list1 = x.split(" ")
            result_list = my_list1[-1]
            id_num_list = my_list1[0]

            if id_num_list not in check_list:
                check_list.append(id_num_list)
                nf.write(x)
                counter(result_list)

if FAIL_num != 0:

    with open("log_fail_report.txt", "w+") as mf:
        with open("log_check.txt", "r") as sf:
            for x in sf.readlines():
                my_list2 = x.split(" ")
                # print(my_list2)
                if 'FAIL' in my_list2[-1]:
                    mf.write(x)
else:
    print("All TestCase is PASS!")

print(f"共{TEXT_num}次，PASS次数：{PASS_num}，FAIL次数：{FAIL_num}")
