from Change import get_newproper, getcmd
from pathlib import Path
import glob
import argparse
import os
import time
def get_arguments():
    parser = argparse.ArgumentParser('arguments')
    parser.add_argument('-t', '--target', type=str, default='Debug', help='target')
    parser.add_argument('-an', '--appname', type=str, default='hello_world', help='appname')   #  'iled_blinky'
    # parser.add_argument('-an', '--appname', type=str, default='iled_blinky', help='appname')
    parser.add_argument('-wp', '--workspace', type=str, default='E:/laa', help='work_path')
    parser.add_argument('-sp', '--sdk_root_path', type=str, default='C:/code_path/sdk/SDK_2_13_0_EVKB-IMXRT1050',
                        help='sdk_root_path')
    parser.add_argument('-idip', '--ide_install_path', type=str,
                        default='D:/ruanjian/PeiXun/MCUXpressoIDE/MCUXpressoIDE_11.7.1_9221',
                        help='ide_install_path')
    args = parser.parse_args()
    return args


def build():

    a = get_arguments()
    workspace = a.workspace
    app_name = a.appname
    target = a.target

    # 删除workspace文件夹下所有内容
    for root, dirs, files in os.walk(workspace, topdown=False):
        for name in files:
            os.remove(os.path.join(root, name))
        for names in dirs:
            os.rmdir(os.path.join(root, names))
    time.sleep(1)


    logfile = f"{workspace}/mcux_build_{app_name}_{target.lower()}.log"
    # logfile = f"{workspace}/x.log"
    print(logfile)
    filepath = f"{workspace}/build.properties"
    properties_file, example_id = get_newproper(filepath, app_name)

    cmd = getcmd(a.ide_install_path, a.workspace, properties_file, logfile)
    os.system(cmd)

    axf_path = Path(glob.glob(f"{workspace}/{example_id}/{target}/*.axf")[0]).as_posix()
    print(axf_path)
    return axf_path

if __name__ == '__main__':

    build()






