import glob
import xml.etree.ElementTree as ET
import os
from pathlib import Path

class project(object):
    def __init__(self, board_id, example_xml, example_name, sdk_name, sdk_location, example_id):
        self.board_id = board_id
        self.example_xml = example_xml
        self.example_name = example_name
        self.sdk_name = sdk_name
        self.sdk_location = sdk_location
        self.example_id = example_id



def default_properties():
    # 生成初始化 properties的字典
    properties = {
            "board.id": " ",   # board_id#
            "nature": "org.eclipse.cdt.core.cnature",
            "standalone": "true",
            "use.io.console": "false",
            "clean.workspace": "false",
            "indexer": "false",
            "build.all": "false",
            "project.build.log": "true",
            "skip.default": "true",
            "verbose": "false",
            "simple.project.name": "false",
            "example.xml": " ",  # example_xml#
            "use.semihost.hardfault.handler": "true",
            "sdk.name": " ",   # sdk_name#
            "sdk.location": " ",   # sdk_location#
            "build.config": "Release",  # target
            "project.build": "true",
            "use.other.files": "true"
        }
    return properties



def getlog(sd_path):
    xml_path = glob.glob(sd_path + "/*.xml")[0]
    return xml_path


# a = getlog('C:/code_path/sdk/SDK_2_13_0_EVKB-IMXRT1050')
# print(a)
my_list = []
sdkpath = 'C:/code_path/sdk/SDK_2_13_0_EVKB-IMXRT1050'
tree = ET.parse(getlog(sdkpath))
root = tree.getroot()
sdk_name = root.attrib["id"]
# print(sdk_name)
sdk_location = sdkpath
# print(sdk_location)
board = root.findall("boards/board")
for x in board:

    # print(board_id)
    example = root.findall("boards/board/examples/example")
    for y in example:
        example_id = y.attrib['id']
        example_name = y.attrib['name']
        board_id = example_id.split('_')[0]
        example_path = Path(y.attrib['path']).as_posix()
        file_mask = y.find("external/files").get('mask')
        # print(example_path)
        abs_path = os.path.join(sdk_location, example_path, file_mask)
        example_xml = Path(abs_path).as_posix()
        # print(example_xml)
        data = project(board_id, example_xml, example_name, sdk_name, sdk_location, example_id)
        my_list.append(data)


def get_newproper(filepath, app_name):

    for x in my_list:
        if app_name == x.example_name:
            dic = default_properties()
            dic["sdk.name"] = x.sdk_name
            dic["board.id"] = x.board_id
            dic["example.xml"] = x.example_xml
            dic["sdk.location"] = x.sdk_location
            dic["build.config"] = 'Debug'
            example_id = x.example_id

    with open(filepath, "w")as f:
        for key, value in dic.items():
            f.write(f"{key:<50}{value}\n")
    return filepath, example_id

def getcmd(ide_path, works_pace, properties_file, logfile):
    build_cmd = [
        f"{ide_path}/ide/mcuxpressoidec.exe",
        "-application",
        "com.nxp.mcuxpresso.headless.application",
        "--launcher.suppressErrors",
        "-noSplash",
        "-consoleLog",
        "-data",
        f"{works_pace}",
        "-run",
        "example.build",
        f"{properties_file}",
        f">> {logfile} 2>&1"  # 标准输出和错误输出 1标准，2错误
    ]
    # 将列表拼接成字符串
    cmd = " ".join(build_cmd)
    return cmd











