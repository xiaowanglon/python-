import io
import logging
from pexpect.spawnbase import SpawnBase

LOGGER = logging.getLogger(__name__)


class SerialSpawn(SpawnBase):
    """Due to pyserial not support file descriptor for windows, fdspawn could not be used.
    # This class implement a spawn for pyserial, all interfaces are defined from the base
    # `SpawnBase`. For more information about the usage, please refer the pexpect documentation.
    #
    # “由于 pyserial 不支持 Windows 的文件描述符，因此无法使用 fdspawn。这个类实现了pyserial的spawn，
    # 所有接口都是从基础'SpawnBase'定义的。有关用法的更多信息，请参阅 pexpect 文档。
    #
    # Simple example:
    #     >>> from mcutk.pserial import Serial
    #     >>> ser = Serial('COM3', 9600)
    #     >>> spawn = ser.SerialSpawn()
    #     >>> spawn.write_expect("Waiting for power mode select..", timeout=3)
    # 简单示例：
    # >>> 从 mcutk.pserial import  Serial
    # >>> ser = Serial（'COM3'， 9600）
    # >>> spawn = ser。SerialSpawn（）
    # >>> spawn.write_expect（“等待电源模式选择..”， timeout=3）
     """

    def __init__(self, serial, **kwargs):
        """
        Arguments:
            serial: {serial.Serial object}
            open: {boolean} open port if it is not open, default True
        参数：
            串行：{串行。串行对象}
            打开：{布尔} 打开端口（如果未打开），默认为 True
        """

        self.log_content = []
        if hasattr(serial, 'reader_isalive'):
            if serial.reader_isalive:
                serial.stop_reader()
                LOGGER.debug('reader thread is stopped!')

        if kwargs.get("encoding") is None:
            kwargs["encoding"] = "utf-8"


        self.auto_open = True
        if "open" in kwargs:
            self.auto_open = kwargs.pop("open")

        if 'codec_errors' not in kwargs:
            kwargs['codec_errors'] = "ignore"

        self.serial = serial
        super().__init__(**kwargs)
        self.log_buffer = io.StringIO()
        
        if self.auto_open:
            self.open()

        self.closed = not self.serial.is_open
        

    def open(self):
        """ Open serial port  打开串口 """

        if not self.serial.is_open:
            LOGGER.info("open port %s, baudrate: %s", self.serial, self.serial.baudrate)
            self.serial.open()

        return self

    def __str__(self):
        return str(self.serial) or f"SerialSpawn(port={self.serial.port})"

    def _log_read_data(self, data):
        """
        Save read data to internal buffers.
        将读取数据保存到内部缓冲区
        """
        # save to spawn.logfile_read
        self._log(data, 'read')
        self.log_buffer.write(data)
        self.log_buffer.flush()

    def read_nonblocking(self, size=1, timeout=None):
        """This is fake nonblocking, the size is decided by how many data in the buffer,
        rather than specific value, this is because big size will block the serial read,
        small size will effect the performance when many data in buffer. timeout is useless.
        他是假非阻塞的，大小是由缓冲区中有多少数据决定的，而不是具体的值，
        这是因为大尺寸会阻塞串行读取，
        小尺寸会影响缓冲区中许多数据的性能。超时是没有用的。
        """
        raw = self.serial.read(self.serial.in_waiting or 1)
        str_data = self._decoder.decode(raw, final=False)
        self._log_read_data(str_data)
        return str_data

    def write(self, data):
        return self.serial.write(data)

    def flush(self):
        """
        Flush serial
        """
        self.serial.flush()

    def get_log(self):
        """
        Get the read log.
        获取读取日志
        """
        if not self.log_buffer:
            return

        self.log_buffer.seek(0)
        return self.log_buffer.read()

    def flush_log(self):
        """
        Flush logfile_read to a readable attribute: SerialSpawn.data
        将logfile_read刷新为可读属性：SerialSpawn.data
        """
        LOGGER.debug("dump reading log to serial object!")
        self.serial.append_data(self.get_log())

    def close(self):
        """Close serial port, and dump the logfile_read to mcutk.PSerial.data.
        If the serial instance is comes from pyserial, dump action will not take.

        关闭串行端口，并将logfile_read转储到 mcutk。
        如果串行实例来自 pyserial，则不会执行转储操作。
        """
        self.serial.close()
        self.flush_log()
        self.closed = True

    def isalive(self):
        """
        Return a boolean the port is open or not
        返回端口是否打开的布尔值
        """
        return self.serial.is_open

    def gether_log(self):
        serial_log = ""
        if self.spawn.before:
            serial_log += self.spawn.before

        if self.spawn.after and isinstance(self.spawn.after, str):
            serial_log += self.spawn.after        

        self.log_content.append(serial_log)

    def test_expect(self, patterns, timeout):
        """ expect all patterns.

        Args:
            patterns ([list]): a list of expect pattern.
            timeout ([int]): timeout value.

        Returns:
            [int]: return result value.
            期待所有模式。
        参数：
            模式（[列表]）：期望模式的列表。
            超时 （[int]）：超时值。
        返回：
            [int]：返回结果值。
        """
        index = self.expect(patterns, timeout=timeout)
        assert index == (len(patterns) - 1), "Not all patterns are matched. Fail match pattern:{}.".format(patterns[index])

        return 0
