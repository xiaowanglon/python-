import time
from .apptest_base import AppTest
from ide_new import get_arguments
a = get_arguments()

class Case(AppTest):
    def __init__(self, board_obj, *args, **kwargs):
        super().__init__(board_obj, *args, **kwargs)
        #   self.expectedPatterns = ["hello world"]
        self.expectedPatterns = [a.appname]

    def interact(self):
        super().interact()   # 调用父类方法 self.spawn.test_expect(self.expectedPatterns, timeout=self.timeout)
        self.spawn.write(r"abcDEF 012345 ~!@#$%\r\n")    # 写入数据
        self.spawn.test_expect([r"abcDEF 012345 ~\!@#\$%"], timeout=self.timeout)     # 读取并匹配数据


# if __name__ == '__main__':
#     stu = Case()
#     stu.interact()