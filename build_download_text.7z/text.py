import subprocess
from ide_new import *
a = get_arguments()
appname = a.appname
axf_path = build()
print(axf_path)
def test(target_proj, filepath):
    # target_proj = "rtwdog"
    # filepath = "D:\Codes\workspace\evkbimxrt1050_rtwdog\Release\evkbimxrt1050_rtwdog.axf"
    cmdlist = [
        "python start.py run -t release -p evkbimxrt1050",
        "--appname",
        f"{target_proj}",
        "-f",
        f"{filepath}"

    ]
    cmd = " ".join(cmdlist)

    # print(cmd)

    command = cmd
    #'cmd.exe'是要执行的命令，stdin、stdout和stderr则分别代表标准输入、标准输出和标准错误输出流。设置shell=True可以支持在命令行中使用管道、通配符等特殊字符。cwd参数指定了要执行命令的文件夹路径。
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, cwd="D:/ruanjian/PeiXun/new_auto/automated_sdk_test-master/automated_sdk_test-master")

    output, error = process.communicate(command.encode())
    print(output.decode())


if __name__ == '__main__':
    test(appname, axf_path)