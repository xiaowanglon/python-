import time
from .apptest_base import AppTest

class Case(AppTest):
    def __init__(self, board_obj, *args, **kwargs):
        super().__init__(board_obj, *args, **kwargs)
        self.expectedPatterns = ["hello world",
            #  "iled_blinky",
                                 "----- Fast test starts -----",
                                "----- Low Byte test starts -----",
                                "Waiting for timeout reset",
                                "Low Byte test succeeded",
                                "----- High Byte test starts -----",
                                "Waiting for timeout reset",
                                "High Byte test succeeded",
                                "----- The end of RTWDOG fast test -----",
                                "----- Refresh test start -----",
                                "----- None-window mode -----",
                                "Refresh rtwdog 1 time",
                                "Waiting for time out reset",
                                "None-window mode reset succeeded",
                                "----Window mode ----",
                                "Waiting for time out reset",
                                "Window mode reset succeeded"
                                 ]
