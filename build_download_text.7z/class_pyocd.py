import os
import argparse
import subprocess
import time
from ide_new import build
from pathlib import Path


axf_path = build()
print(axf_path)

#
# def chuancan():
#     parser = argparse.ArgumentParser('arguments')
#     parser.add_argument('-ap', '--about_path', type=str, default='D:\GNU', help='shu_ru_gdb_tool_about_path')  #  required=True,
#     args = parser.parse_args()
#     return args


class pyocd_gdb:

    def scan_gdb(self, xpath):
        for root, dirs, files in os.walk(xpath):
            for file in files:
                if file == 'arm-none-eabi-gdb.exe':
                    gdb_path = os.path.join(root, file)
                    return gdb_path


def run_exe(exe_path):
    print('start')

    gdb_exe = subprocess.Popen(exe_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)

    gdb_exe.stdin.write('target remote localhost:3565\n'.encode())

    gdb_exe.stdin.write('monitor reset --halt\n'.encode())

    gdb_exe.stdin.write('monitor halt\n'.encode())

    gdb_exe.stdin.write(f'load {axf_path}\n'.encode())

    gdb_exe.stdin.write('q\n'.encode())
    gdb_exe.communicate()   # 读取管子里的指令
    print('================')
    # gdb_exe.wait()
    print('end')


def load():

    os.system('python -m pyocd list')
    serve_t = ['python -m pyocd gdbserver --no-wait',
                '-Osemihost_console_type=console -Okeep_unwritten-0',
                '--port 3565 -u',
                '0227000041114e45004b300cc403001e5ab1000097969900']
    serve_ta = ' '.join(serve_t)
    print(serve_ta)
    serve = subprocess.Popen(serve_ta, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)
    # serve.stdin.flush()

    print('aaaaaaa')
    sc = pyocd_gdb()

    b = Path(sc.scan_gdb('D:\GNU')).as_posix()
    print(b)
    run_exe(b)
    print("-------------")
    serve.communicate()
    print("============")


if __name__ == '__main__':
    load()



